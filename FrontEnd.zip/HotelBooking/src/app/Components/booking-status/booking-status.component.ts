import { Component } from '@angular/core';

@Component({
  selector: 'app-booking-status',
  imports: [],
  templateUrl: './booking-status.component.html',
  styleUrl: './booking-status.component.css'
})
export class BookingStatusComponent {

}
