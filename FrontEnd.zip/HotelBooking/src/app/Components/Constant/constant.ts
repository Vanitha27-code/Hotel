export const Constant = {
    BASE_URI : 'https://localhost:7140/api/',
    LOGIN:'Auth/Login',
    Register:'Auth/Register',
}