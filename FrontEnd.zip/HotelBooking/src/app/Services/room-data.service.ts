import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class RoomDataService {
  private RoomUrl = ''
  constructor() { }
}
