export interface Booking {
  userID: number;
  roomID: number;
  checkInDate: string;
  checkOutDate: string;
  status: string;
  paymentID: number;
}